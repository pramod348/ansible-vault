SECRET_KEY = "AVerySafeExampleKey123!"
DB_PATH = "postgresql://example_user:myVerySecretDatabasePassword@localhost:5432/example_db"
ADMIN_GROUPS = ["Read-only", "Read-write", "Super"]
